CREATE TABLE IF NOT EXISTS refunds (
    id INT NOT NULL AUTO_INCREMENT,
    user_id INT DEFAULT NULL,
    account_number VARCHAR(30) DEFAULT NULL,
    amount DECIMAL(15,2) DEFAULT NULL,
    reason VARCHAR(255) DEFAULT NULL,
    refunded_by VARCHAR(200) DEFAULT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
