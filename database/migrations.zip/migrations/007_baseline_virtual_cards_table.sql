CREATE TABLE IF NOT EXISTS virtual_cards (
    id INT NOT NULL AUTO_INCREMENT,
    user_id INT DEFAULT NULL,
    card_number VARCHAR(30) DEFAULT NULL,
    expiry_date VARCHAR(10) DEFAULT NULL,
    cvv VARCHAR(10) DEFAULT NULL,
    cardholder_name VARCHAR(200) DEFAULT NULL,
    balance DECIMAL(15,2) DEFAULT NULL,
    status VARCHAR(30) DEFAULT NULL,
    is_virtual_card_approved TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
