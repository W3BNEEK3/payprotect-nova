ALTER TABLE user_compliance_codes
    ADD COLUMN flag_id INT DEFAULT NULL AFTER compliance_id;

ALTER TABLE user_compliance_codes
    ADD CONSTRAINT fk_ucc_flag FOREIGN KEY (flag_id) REFERENCES compliance_flags(id);
