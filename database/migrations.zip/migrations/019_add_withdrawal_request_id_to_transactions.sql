ALTER TABLE transactions
    ADD COLUMN withdrawal_request_id INT DEFAULT NULL AFTER receiver_id;

ALTER TABLE transactions
    ADD CONSTRAINT fk_txn_withdrawal FOREIGN KEY (withdrawal_request_id) REFERENCES withdrawal_requests(id);
