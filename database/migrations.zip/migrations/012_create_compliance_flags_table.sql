CREATE TABLE IF NOT EXISTS compliance_flags (
    id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    reason VARCHAR(50) NOT NULL COMMENT 'new_account, high_credit_volume, or manual',
    status VARCHAR(20) NOT NULL DEFAULT 'open' COMMENT 'open or resolved',
    triggered_amount DECIMAL(15,2) DEFAULT NULL,
    triggered_currency VARCHAR(10) DEFAULT NULL,
    created_by INT DEFAULT NULL COMMENT 'admin id if manually flagged, NULL if automatic',
    resolved_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id),
    KEY status (status),
    CONSTRAINT fk_flag_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
