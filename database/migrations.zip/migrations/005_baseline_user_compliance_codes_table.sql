CREATE TABLE IF NOT EXISTS user_compliance_codes (
    id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    compliance_id INT NOT NULL,
    code VARCHAR(50) DEFAULT NULL,
    notes VARCHAR(500) DEFAULT NULL,
    assigned_by VARCHAR(200) DEFAULT NULL,
    is_cleared TINYINT(1) DEFAULT 0,
    cleared_at DATETIME DEFAULT NULL,
    assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id),
    KEY compliance_id (compliance_id),
    CONSTRAINT fk_ucc_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_ucc_requirement FOREIGN KEY (compliance_id) REFERENCES compliance_requirements(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
