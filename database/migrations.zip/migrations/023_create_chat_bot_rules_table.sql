CREATE TABLE IF NOT EXISTS chat_bot_rules (
    id INT NOT NULL AUTO_INCREMENT,
    trigger_keywords VARCHAR(500) NOT NULL COMMENT 'comma-separated keywords/phrases',
    response TEXT NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
