CREATE TABLE IF NOT EXISTS mail_settings (
    id INT NOT NULL AUTO_INCREMENT,
    driver VARCHAR(20) NOT NULL COMMENT 'smtp or resend',
    config TEXT DEFAULT NULL COMMENT 'JSON-encoded driver-specific settings',
    is_active TINYINT(1) DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
