CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    method VARCHAR(50) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(10) NOT NULL,
    destination_details TEXT DEFAULT NULL COMMENT 'JSON-encoded, method-specific fields',
    status VARCHAR(20) NOT NULL DEFAULT 'pending_review' COMMENT 'pending_review, approved, processing, completed, rejected',
    rejection_reason VARCHAR(255) DEFAULT NULL,
    reviewed_by INT DEFAULT NULL,
    reviewed_at DATETIME DEFAULT NULL,
    completed_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id),
    KEY status (status),
    CONSTRAINT fk_wr_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
