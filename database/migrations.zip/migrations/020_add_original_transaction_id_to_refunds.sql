ALTER TABLE refunds
    ADD COLUMN original_transaction_id INT DEFAULT NULL AFTER user_id;

ALTER TABLE refunds
    ADD CONSTRAINT fk_refund_transaction FOREIGN KEY (original_transaction_id) REFERENCES transactions(id);
