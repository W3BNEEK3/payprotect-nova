ALTER TABLE virtual_cards
    ADD COLUMN card_number_encrypted VARBINARY(255) DEFAULT NULL AFTER card_number,
    ADD COLUMN cvv_encrypted VARBINARY(255) DEFAULT NULL AFTER cvv;
