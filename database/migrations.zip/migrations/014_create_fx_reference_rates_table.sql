CREATE TABLE IF NOT EXISTS fx_reference_rates (
    id INT NOT NULL AUTO_INCREMENT,
    currency_code VARCHAR(10) NOT NULL,
    rate_to_usd DECIMAL(15,6) NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY currency_code (currency_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO fx_reference_rates (currency_code, rate_to_usd) VALUES
    ('USD', 1.000000),
    ('EUR', 1.080000),
    ('GBP', 1.270000);
