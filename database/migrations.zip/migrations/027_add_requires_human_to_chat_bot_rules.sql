ALTER TABLE chat_bot_rules ADD COLUMN requires_human TINYINT(1) DEFAULT 0 AFTER response;
